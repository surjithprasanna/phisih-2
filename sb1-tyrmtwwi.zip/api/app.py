from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import os
import numpy as np
from feature_extractor import extract_features
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load the model
model_path = os.path.join(os.path.dirname(__file__), '../model/xgboost_phishing_model.pkl')

# Check if model exists, otherwise we'll respond with an appropriate message
model_exists = os.path.exists(model_path)
if model_exists:
    try:
        model = joblib.load(model_path)
        logger.info("Model loaded successfully")
    except Exception as e:
        logger.error(f"Error loading model: {e}")
        model_exists = False
else:
    logger.warning("Model file not found. Please train the model first.")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        url = data.get('url')
        
        if not url:
            return jsonify({"error": "URL is required"}), 400
        
        logger.info(f"Received prediction request for URL: {url}")
        
        if not model_exists:
            # For demo purposes, return a simulated response if model isn't available
            import random
            is_phishing = random.random() > 0.5
            confidence = random.uniform(0.7, 0.98)
            
            logger.info(f"Returning simulated prediction: {'phishing' if is_phishing else 'legitimate'}")
            
            return jsonify({
                "result": "phishing" if is_phishing else "legitimate",
                "confidence": confidence
            })
        
        # Extract features from the URL
        features = extract_features(url)
        
        # Make prediction
        features_array = np.array(features).reshape(1, -1)
        prediction = model.predict(features_array)[0]
        confidence = model.predict_proba(features_array)[0][1] if prediction == 1 else model.predict_proba(features_array)[0][0]
        
        result = "phishing" if prediction == 1 else "legitimate"
        logger.info(f"Prediction: {result}, Confidence: {confidence}")
        
        return jsonify({
            "result": result,
            "confidence": float(confidence)
        })
    
    except Exception as e:
        logger.error(f"Error during prediction: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/stats', methods=['GET'])
def get_stats():
    # In a real implementation, this would query a database
    # For demo purposes, we'll return mock data
    return jsonify({
        "total": 128,
        "phishing": 42,
        "legitimate": 86
    })

@app.route('/recent-scans', methods=['GET'])
def get_recent_scans():
    # In a real implementation, this would query a database
    # For demo purposes, we'll return mock data
    import datetime
    
    now = datetime.datetime.now()
    
    scans = [
        {
            "id": 1,
            "url": "https://legitimate-bank.com",
            "result": "legitimate",
            "confidence": 0.96,
            "timestamp": now.isoformat()
        },
        {
            "id": 2,
            "url": "https://phishing-example.com",
            "result": "phishing",
            "confidence": 0.89,
            "timestamp": (now - datetime.timedelta(hours=1)).isoformat()
        },
        {
            "id": 3,
            "url": "https://shopping-site.com",
            "result": "legitimate",
            "confidence": 0.92,
            "timestamp": (now - datetime.timedelta(hours=2)).isoformat()
        },
        {
            "id": 4,
            "url": "https://malicious-login.net",
            "result": "phishing",
            "confidence": 0.95,
            "timestamp": (now - datetime.timedelta(hours=3)).isoformat()
        },
        {
            "id": 5,
            "url": "https://news-website.org",
            "result": "legitimate",
            "confidence": 0.88,
            "timestamp": (now - datetime.timedelta(hours=4)).isoformat()
        }
    ]
    
    return jsonify(scans)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)