import re
import urllib.parse
import requests
from bs4 import BeautifulSoup
import socket
import whois
import ssl
import datetime
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def extract_features(url):
    """
    Extract features from a URL for phishing detection
    
    Returns:
        list: A list of features
    """
    try:
        # Initialize feature list
        features = []
        
        # URL features
        features.extend(extract_url_features(url))
        
        # Try to get domain features
        try:
            features.extend(extract_domain_features(url))
        except Exception as e:
            logger.warning(f"Error extracting domain features: {e}")
            # Add placeholder values for domain features
            features.extend([0, 0, 0])
        
        # Try to get HTML/JS features
        try:
            features.extend(extract_html_features(url))
        except Exception as e:
            logger.warning(f"Error extracting HTML features: {e}")
            # Add placeholder values for HTML features
            features.extend([0, 0, 0])
        
        return features
    
    except Exception as e:
        logger.error(f"Error in feature extraction: {e}")
        # Return a default feature vector in case of errors
        return [0] * 9  # Assuming we have 9 features total

def extract_url_features(url):
    """Extract features from the URL itself"""
    features = []
    
    # 1. URL length
    url_length = len(url)
    features.append(url_length)
    
    # 2. Number of dots in the URL
    dot_count = url.count('.')
    features.append(dot_count)
    
    # 3. Presence of @ symbol (1 if present, 0 if not)
    has_at_symbol = 1 if '@' in url else 0
    features.append(has_at_symbol)
    
    # 4. Presence of IP address in URL (1 if present, 0 if not)
    ip_pattern = re.compile(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')
    has_ip = 1 if ip_pattern.search(url) else 0
    features.append(has_ip)
    
    # 5. Presence of URL shortener (1 if present, 0 if not)
    shorteners = ['bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'is.gd']
    parsed_url = urllib.parse.urlparse(url)
    is_shortener = 1 if any(shortener in parsed_url.netloc for shortener in shorteners) else 0
    features.append(is_shortener)
    
    return features

def extract_domain_features(url):
    """Extract features related to the domain"""
    features = []
    
    parsed_url = urllib.parse.urlparse(url)
    domain = parsed_url.netloc
    
    if not domain:
        return [0, 0, 0]  # Default values if no domain found
    
    try:
        # 1. Domain age in days (if available)
        domain_info = whois.whois(domain)
        
        if domain_info.creation_date:
            if isinstance(domain_info.creation_date, list):
                creation_date = domain_info.creation_date[0]
            else:
                creation_date = domain_info.creation_date
                
            domain_age = (datetime.datetime.now() - creation_date).days
            # Normalize age: older domains are more likely legitimate
            # Map to range 0-1 where 1 means very old (trustworthy)
            normalized_age = min(domain_age / 365, 1)  # Cap at 1 year
        else:
            normalized_age = 0  # No creation date is suspicious
    except:
        normalized_age = 0
        
    features.append(normalized_age)
    
    # 2. Check SSL certificate (1 if valid, 0 if not)
    has_valid_ssl = 0
    try:
        hostname = domain.split(':')[0]
        context = ssl.create_default_context()
        with socket.create_connection((hostname, 443), timeout=3) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                # Certificate exists
                has_valid_ssl = 1
    except:
        has_valid_ssl = 0
        
    features.append(has_valid_ssl)
    
    # 3. Domain expiration period (if available)
    try:
        if domain_info.expiration_date:
            if isinstance(domain_info.expiration_date, list):
                expiration_date = domain_info.expiration_date[0]
            else:
                expiration_date = domain_info.expiration_date
                
            days_to_expiration = (expiration_date - datetime.datetime.now()).days
            # Normalize: longer expiration is more likely legitimate
            # Map to range 0-1 where 1 means long expiration (trustworthy)
            normalized_expiration = min(days_to_expiration / (365 * 2), 1)  # Cap at 2 years
        else:
            normalized_expiration = 0  # No expiration date is suspicious
    except:
        normalized_expiration = 0
        
    features.append(normalized_expiration)
    
    return features

def extract_html_features(url):
    """Extract features from the HTML content"""
    features = []
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=5)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 1. Count of <form> tags
        form_count = len(soup.find_all('form'))
        features.append(min(form_count, 5))  # Cap at 5 to avoid outliers
        
        # 2. Presence of external form actions (1 if present, 0 if not)
        external_form = 0
        forms = soup.find_all('form')
        parsed_url = urllib.parse.urlparse(url)
        base_domain = parsed_url.netloc
        
        for form in forms:
            if form.get('action'):
                action_url = form.get('action')
                # Check if it's an absolute URL
                if action_url.startswith('http'):
                    action_domain = urllib.parse.urlparse(action_url).netloc
                    if action_domain and action_domain != base_domain:
                        external_form = 1
                        break
                        
        features.append(external_form)
        
        # 3. Count of <iframe> tags
        iframe_count = len(soup.find_all('iframe'))
        features.append(min(iframe_count, 5))  # Cap at 5 to avoid outliers
        
    except Exception as e:
        logger.warning(f"Error fetching or parsing URL content: {e}")
        # If we can't access the website, that's suspicious
        features = [0, 0, 0]
        
    return features