# Phishing Dataset

This directory should contain the dataset files for training and testing the phishing detection model.

## Expected File Format

The main dataset file should be named `phishing_dataset.csv` and should contain the following:

- URL features (length, dots, @symbol, etc.)
- Domain features (age, SSL status, etc.)
- HTML/JS features (form count, iframes, etc.)
- Label (1 for phishing, 0 for legitimate)

## Synthetic Data

If no dataset is provided, the training script will generate synthetic data for demonstration purposes.

## Sources for Real Phishing Datasets

If you want to use real data, consider the following sources:

1. [PhishTank](https://www.phishtank.com/developer_info.php)
2. [OpenPhish](https://openphish.com/)
3. [UCI Machine Learning Repository: Phishing Websites Dataset](https://archive.ics.uci.edu/ml/datasets/phishing+websites)
4. [Kaggle Phishing Dataset](https://www.kaggle.com/datasets/shashwatwork/phishing-dataset-for-machine-learning)

## Data Preprocessing

Before using any dataset, make sure to:

1. Clean the data (remove duplicates, handle missing values)
2. Extract relevant features
3. Balance the dataset if necessary (similar number of phishing and legitimate examples)
4. Normalize/scale features if needed