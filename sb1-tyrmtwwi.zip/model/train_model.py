import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report
import xgboost as xgb
import joblib
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def load_data(data_path):
    """
    Load the phishing dataset
    
    Args:
        data_path: Path to the dataset
        
    Returns:
        X: Features
        y: Labels
    """
    logger.info(f"Loading data from {data_path}")
    
    # For demonstration, create synthetic data if the file doesn't exist
    if not os.path.exists(data_path):
        logger.warning(f"Data file not found. Creating synthetic dataset for demonstration.")
        return create_synthetic_data()
    
    # Load the actual data
    df = pd.read_csv(data_path)
    
    # Assuming the dataset has features and the last column is the label
    X = df.iloc[:, :-1]
    y = df.iloc[:, -1]
    
    return X, y

def create_synthetic_data():
    """Create synthetic data for demonstration purposes"""
    # Generate 1000 samples with 9 features
    np.random.seed(42)
    n_samples = 1000
    n_features = 9
    
    # Generate synthetic features
    X = np.random.rand(n_samples, n_features)
    
    # URL length (feature 0): phishing sites often have longer URLs
    X[:, 0] = np.random.normal(50, 20, n_samples)  # legitimate
    X[n_samples//2:, 0] = np.random.normal(100, 30, n_samples//2)  # phishing
    
    # Number of dots (feature 1): phishing sites often have more subdomains
    X[:, 1] = np.random.randint(1, 3, n_samples)  # legitimate
    X[n_samples//2:, 1] = np.random.randint(3, 6, n_samples//2)  # phishing
    
    # @ symbol (feature 2): more common in phishing
    X[:, 2] = np.random.choice([0, 1], n_samples, p=[0.95, 0.05])  # legitimate
    X[n_samples//2:, 2] = np.random.choice([0, 1], n_samples//2, p=[0.6, 0.4])  # phishing
    
    # IP address (feature 3): more common in phishing
    X[:, 3] = np.random.choice([0, 1], n_samples, p=[0.98, 0.02])  # legitimate
    X[n_samples//2:, 3] = np.random.choice([0, 1], n_samples//2, p=[0.7, 0.3])  # phishing
    
    # URL shortener (feature 4): can be used in phishing
    X[:, 4] = np.random.choice([0, 1], n_samples, p=[0.9, 0.1])  # legitimate
    X[n_samples//2:, 4] = np.random.choice([0, 1], n_samples//2, p=[0.7, 0.3])  # phishing
    
    # Domain age (feature 5): phishing sites are often newer
    X[:, 5] = np.random.beta(5, 2, n_samples)  # legitimate (older domains)
    X[n_samples//2:, 5] = np.random.beta(1, 5, n_samples//2)  # phishing (newer domains)
    
    # SSL certificate (feature 6): less common in phishing
    X[:, 6] = np.random.choice([0, 1], n_samples, p=[0.1, 0.9])  # legitimate
    X[n_samples//2:, 6] = np.random.choice([0, 1], n_samples//2, p=[0.6, 0.4])  # phishing
    
    # Domain expiration (feature 7): phishing domains expire sooner
    X[:, 7] = np.random.beta(5, 2, n_samples)  # legitimate (longer expiration)
    X[n_samples//2:, 7] = np.random.beta(2, 5, n_samples//2)  # phishing (shorter expiration)
    
    # Form count + iframe + external form (features 8-10): more suspicious elements in phishing
    X[:, 8] = np.random.randint(0, 2, n_samples)  # legitimate
    X[n_samples//2:, 8] = np.random.randint(1, 5, n_samples//2)  # phishing
    
    # Generate labels (0 for legitimate, 1 for phishing)
    y = np.zeros(n_samples)
    y[n_samples//2:] = 1
    
    # Convert to pandas DataFrame and Series
    X_df = pd.DataFrame(X, columns=[
        'url_length', 'dot_count', 'has_at_symbol', 'has_ip', 'is_shortener',
        'domain_age', 'has_valid_ssl', 'domain_expiration', 'suspicious_elements'
    ])
    y_series = pd.Series(y)
    
    return X_df, y_series

def train_model(X, y):
    """
    Train XGBoost model for phishing detection
    
    Args:
        X: Features
        y: Labels
        
    Returns:
        Trained XGBoost model
    """
    logger.info("Splitting data into train and test sets")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    logger.info("Training XGBoost model")
    model = xgb.XGBClassifier(
        n_estimators=100,
        learning_rate=0.1,
        max_depth=5,
        min_child_weight=1,
        gamma=0,
        subsample=0.8,
        colsample_bytree=0.8,
        objective='binary:logistic',
        random_state=42
    )
    
    model.fit(X_train, y_train)
    
    logger.info("Evaluating model on test set")
    y_pred = model.predict(X_test)
    
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    
    logger.info(f"Model Evaluation Metrics:")
    logger.info(f"Accuracy: {accuracy:.4f}")
    logger.info(f"Precision: {precision:.4f}")
    logger.info(f"Recall: {recall:.4f}")
    logger.info(f"F1 Score: {f1:.4f}")
    
    logger.info("\nDetailed Classification Report:")
    logger.info(classification_report(y_test, y_pred))
    
    return model

def save_model(model, model_path):
    """
    Save the trained model to disk
    
    Args:
        model: Trained XGBoost model
        model_path: Path to save the model
    """
    logger.info(f"Saving model to {model_path}")
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    joblib.dump(model, model_path)
    logger.info("Model saved successfully")

def main():
    logger.info("Starting model training process")
    
    # Paths
    data_path = os.path.join(os.path.dirname(__file__), '../data/phishing_dataset.csv')
    model_path = os.path.join(os.path.dirname(__file__), 'xgboost_phishing_model.pkl')
    
    # Load or create data
    X, y = load_data(data_path)
    
    # Train model
    model = train_model(X, y)
    
    # Save model
    save_model(model, model_path)
    
    logger.info("Model training completed successfully")

if __name__ == "__main__":
    main()