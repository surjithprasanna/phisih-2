// Listen for installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('PhishGuard extension installed');
});

// Message handling from popup or content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getCurrentUrl') {
    // Get the current tab's URL
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].url) {
        sendResponse({ url: tabs[0].url });
      } else {
        sendResponse({ error: 'No active tab found' });
      }
    });
    // Return true to indicate we will send a response asynchronously
    return true;
  }
});

// In a full implementation, we might add:
// 1. Real-time checking of URLs as they're loaded
// 2. Badge updates to show site status
// 3. History tracking of scanned sites
// 4. Notifications for dangerous sites