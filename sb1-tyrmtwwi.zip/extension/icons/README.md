# Extension Icons

This directory should contain the following icon files:

- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels)
- icon128.png (128x128 pixels)

These icons will be used in the Chrome browser extension UI.

For a complete extension, replace this file with actual icon image files.