document.addEventListener('DOMContentLoaded', () => {
  const scanBtn = document.getElementById('scan-btn');
  const settingsBtn = document.getElementById('settings-btn');
  const loadingElement = document.getElementById('loading');
  const resultElement = document.getElementById('result');
  const errorElement = document.getElementById('error');
  const resultTitle = document.getElementById('result-title');
  const resultMessage = document.getElementById('result-message');
  const statusIcon = document.getElementById('status-icon');
  const confidenceBarFill = document.getElementById('confidence-bar-fill');
  const confidencePercentage = document.getElementById('confidence-percentage');
  const errorMessage = document.getElementById('error-message');

  // Initially hide loading and result sections
  loadingElement.classList.add('hidden');
  resultElement.classList.add('hidden');
  errorElement.classList.add('hidden');

  // Get the current URL when popup is opened
  getCurrentTabUrl().then(url => {
    // Store the current URL for scanning
    window.currentUrl = url;
  }).catch(error => {
    console.error('Error getting current tab URL:', error);
    showError('Unable to access current tab URL');
  });

  // Scan button click handler
  scanBtn.addEventListener('click', () => {
    if (!window.currentUrl) {
      showError('No URL available to scan');
      return;
    }
    
    scanWebsite(window.currentUrl);
  });

  // Settings button click handler
  settingsBtn.addEventListener('click', () => {
    // In a real extension, this would open a settings page
    alert('Settings functionality would be implemented in a full extension');
  });

  // Function to get the current tab URL
  async function getCurrentTabUrl() {
    return new Promise((resolve, reject) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].url) {
          resolve(tabs[0].url);
        } else {
          reject(new Error('No active tab found'));
        }
      });
    });
  }

  // Function to scan a website
  function scanWebsite(url) {
    // Show loading, hide result and error
    loadingElement.classList.remove('hidden');
    resultElement.classList.add('hidden');
    errorElement.classList.add('hidden');

    // In a real extension, this would call your deployed API
    // For demo purposes, we'll simulate an API call with a timeout
    setTimeout(() => {
      // This is where we would make a fetch request to the API
      // For demo purposes, we'll create a simulated response
      const apiUrl = 'http://localhost:5000/predict';
      
      // This would be a real fetch in a production extension
      simulateApiCall(url)
        .then(response => {
          displayResult(response);
        })
        .catch(error => {
          console.error('Error scanning website:', error);
          showError('Failed to scan website. Please try again.');
        })
        .finally(() => {
          loadingElement.classList.add('hidden');
        });
    }, 1500); // Simulate network delay
  }

  // Simulate API call (in a real extension, this would be a fetch to your API)
  function simulateApiCall(url) {
    return new Promise((resolve, reject) => {
      // Simulate different results based on URL patterns for demo purposes
      if (url.includes('phish') || url.includes('malicious')) {
        resolve({
          result: 'phishing',
          confidence: 0.92
        });
      } else if (url.includes('example') || url.includes('test')) {
        resolve({
          result: 'legitimate',
          confidence: 0.85
        });
      } else {
        // For most URLs, generate a random result with bias toward legitimate
        const isPhishing = Math.random() > 0.7;
        const confidence = isPhishing 
          ? 0.75 + Math.random() * 0.2 // Phishing confidence between 0.75-0.95
          : 0.85 + Math.random() * 0.13; // Legitimate confidence between 0.85-0.98
          
        resolve({
          result: isPhishing ? 'phishing' : 'legitimate',
          confidence: confidence
        });
      }
    });
  }

  // Display scan result
  function displayResult(data) {
    resultElement.classList.remove('hidden');
    
    const isPhishing = data.result === 'phishing';
    const confidencePercent = Math.round(data.confidence * 100);
    
    // Update the status icon
    statusIcon.className = 'status-icon ' + (isPhishing ? 'danger' : 'safe');
    statusIcon.innerHTML = isPhishing 
      ? '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>'
      : '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>';
    
    // Update the result title and message
    if (isPhishing) {
      resultTitle.textContent = 'Warning: Potential Phishing';
      resultTitle.style.color = '#ef4444';
      resultMessage.textContent = 'This website shows characteristics of a phishing attempt. Be careful!';
    } else {
      resultTitle.textContent = 'Website Appears Safe';
      resultTitle.style.color = '#10b981';
      resultMessage.textContent = 'This website appears to be legitimate.';
    }
    
    // Update the confidence bar
    confidenceBarFill.style.width = `${confidencePercent}%`;
    confidenceBarFill.className = 'confidence-bar-fill ' + (isPhishing ? 'danger' : 'safe');
    confidencePercentage.textContent = `${confidencePercent}%`;
  }

  // Show error message
  function showError(message) {
    errorElement.classList.remove('hidden');
    loadingElement.classList.add('hidden');
    resultElement.classList.add('hidden');
    errorMessage.textContent = message;
  }
});