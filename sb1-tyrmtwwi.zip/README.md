# PhishGuard: Phishing Website Detection System

A comprehensive system for detecting phishing websites using machine learning, consisting of:
1. A Python-based machine learning model using XGBoost
2. A Flask REST API for serving predictions
3. A Chrome extension for real-time website checking
4. A React-based web interface for manual URL checking and viewing statistics

## Project Structure

```
/phishing-detection-system
├── /model                  # Machine learning model files
│   ├── train_model.py      # Script for training the XGBoost model
│   └── xgboost_phishing_model.pkl  # Saved model (generated after training)
├── /api                    # Flask API
│   ├── app.py              # Main Flask application
│   ├── feature_extractor.py # Feature extraction utilities
│   └── requirements.txt    # Python dependencies
├── /extension              # Chrome extension
│   ├── manifest.json       # Extension manifest file
│   ├── popup.html          # Extension popup interface
│   ├── popup.css           # Styles for the popup
│   ├── popup.js            # Popup functionality
│   ├── background.js       # Background script
│   └── /icons              # Extension icons
├── /data                   # Dataset for training/testing
│   └── README.md           # Dataset information
├── /src                    # React web application
│   ├── /components         # UI components
│   ├── /pages              # Page components
│   ├── /services           # API services
│   ├── /types              # TypeScript type definitions
│   └── App.tsx             # Main React component
├── package.json            # Project dependencies
└── README.md               # Project documentation
```

## Getting Started

### Prerequisites

- Node.js (v14+)
- Python (v3.7+)
- Chrome browser (for extension testing)

### Installation

1. Clone the repository:
```
git clone https://github.com/yourusername/phishing-detection-system.git
cd phishing-detection-system
```

2. Install JavaScript dependencies:
```
npm install
```

3. Install Python dependencies:
```
cd api
pip install -r requirements.txt
cd ..
```

4. Train the model:
```
cd model
python train_model.py
cd ..
```

5. Start the Flask API:
```
npm run flask
```

6. In a new terminal, start the web application:
```
npm run dev
```

### Chrome Extension Installation

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in the top-right corner)
3. Click "Load unpacked" and select the `/extension` directory from this project
4. The PhishGuard extension should now be installed and visible in your browser toolbar

## Usage

### Web Interface

Visit `http://localhost:5173` to access the web interface, where you can:
- Manually check URLs for phishing
- View detection statistics
- Learn about the project

### Chrome Extension

1. Click the PhishGuard icon in your browser toolbar
2. Click "Scan Website" to check the current site
3. View the result with confidence score
4. Be warned if the site is potentially dangerous

### API Endpoints

- `POST /predict` - Check if a URL is phishing or legitimate
  - Request: `{ "url": "https://example.com" }`
  - Response: `{ "result": "legitimate", "confidence": 0.95 }`

- `GET /stats` - Get detection statistics
- `GET /recent-scans` - Get recent scan history

## Security Considerations

This system should be used as an additional layer of security, not as the sole method of protection against phishing. Always exercise caution when entering sensitive information online.

## License

This project is licensed under the MIT License - see the LICENSE file for details.