export interface Scan {
  id: number;
  url: string;
  result: 'phishing' | 'legitimate';
  confidence: number;
  timestamp: string;
}

export interface Stats {
  total: number;
  phishing: number;
  legitimate: number;
}