import React, { useState, useEffect } from 'react';
import { BarChart, Shield, AlertTriangle, RefreshCw } from 'lucide-react';
import { getStats, getRecentScans } from '../services/apiService';
import { Scan } from '../types';

const DashboardPage: React.FC = () => {
  const [stats, setStats] = useState({ total: 0, phishing: 0, legitimate: 0 });
  const [recentScans, setRecentScans] = useState<Scan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // In a real app, these would be actual API calls
        // For demo purposes, we'll use mock data
        setStats({
          total: 128,
          phishing: 42,
          legitimate: 86
        });
        
        setRecentScans([
          { id: 1, url: 'https://legitimate-bank.com', result: 'legitimate', confidence: 0.96, timestamp: new Date().toISOString() },
          { id: 2, url: 'https://phishing-example.com', result: 'phishing', confidence: 0.89, timestamp: new Date(Date.now() - 3600000).toISOString() },
          { id: 3, url: 'https://shopping-site.com', result: 'legitimate', confidence: 0.92, timestamp: new Date(Date.now() - 7200000).toISOString() },
          { id: 4, url: 'https://malicious-login.net', result: 'phishing', confidence: 0.95, timestamp: new Date(Date.now() - 10800000).toISOString() },
          { id: 5, url: 'https://news-website.org', result: 'legitimate', confidence: 0.88, timestamp: new Date(Date.now() - 14400000).toISOString() },
        ]);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const refreshData = () => {
    setLoading(true);
    // In a real app, this would refetch the data
    setTimeout(() => setLoading(false), 1000);
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-800 flex items-center">
          <BarChart className="h-6 w-6 mr-2 text-blue-600" />
          Dashboard
        </h1>
        <button 
          onClick={refreshData} 
          className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
        >
          <RefreshCw className="h-4 w-4 mr-1" />
          Refresh Data
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Total Scans</p>
              <h3 className="text-3xl font-bold text-gray-800">{stats.total}</h3>
            </div>
            <div className="bg-blue-100 p-2 rounded-full text-blue-600">
              <Shield className="h-6 w-6" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Phishing Detected</p>
              <h3 className="text-3xl font-bold text-red-600">{stats.phishing}</h3>
            </div>
            <div className="bg-red-100 p-2 rounded-full text-red-600">
              <AlertTriangle className="h-6 w-6" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Legitimate Sites</p>
              <h3 className="text-3xl font-bold text-green-600">{stats.legitimate}</h3>
            </div>
            <div className="bg-green-100 p-2 rounded-full text-green-600">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Recent Scans</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-4 py-3 text-gray-600">URL</th>
                <th className="px-4 py-3 text-gray-600">Result</th>
                <th className="px-4 py-3 text-gray-600">Confidence</th>
                <th className="px-4 py-3 text-gray-600">Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {recentScans.map((scan) => (
                <tr key={scan.id} className="border-t">
                  <td className="px-4 py-3 truncate max-w-xs">{scan.url}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      scan.result === 'phishing' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {scan.result === 'phishing' ? 'Phishing' : 'Legitimate'}
                    </span>
                  </td>
                  <td className="px-4 py-3">{(scan.confidence * 100).toFixed(2)}%</td>
                  <td className="px-4 py-3 text-gray-500">{formatTimestamp(scan.timestamp)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-4">Detection Metrics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-medium mb-2">Accuracy</h3>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div className="bg-blue-600 h-4 rounded-full" style={{ width: '92%' }}></div>
            </div>
            <p className="text-right mt-1 text-gray-600">92%</p>
          </div>
          <div>
            <h3 className="text-lg font-medium mb-2">Precision</h3>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div className="bg-blue-600 h-4 rounded-full" style={{ width: '88%' }}></div>
            </div>
            <p className="text-right mt-1 text-gray-600">88%</p>
          </div>
          <div>
            <h3 className="text-lg font-medium mb-2">Recall</h3>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div className="bg-blue-600 h-4 rounded-full" style={{ width: '94%' }}></div>
            </div>
            <p className="text-right mt-1 text-gray-600">94%</p>
          </div>
          <div>
            <h3 className="text-lg font-medium mb-2">F1 Score</h3>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div className="bg-blue-600 h-4 rounded-full" style={{ width: '91%' }}></div>
            </div>
            <p className="text-right mt-1 text-gray-600">91%</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;