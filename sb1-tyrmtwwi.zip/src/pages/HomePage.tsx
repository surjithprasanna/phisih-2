import React, { useState } from 'react';
import { Shield, AlertTriangle, CheckCircle } from 'lucide-react';
import { scanUrl } from '../services/apiService';

const HomePage: React.FC = () => {
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<{ result: string; confidence: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) {
      setError('Please enter a URL');
      return;
    }

    try {
      setLoading(true);
      setError('');
      const data = await scanUrl(url);
      setResult(data);
    } catch (err) {
      setError('Failed to scan URL. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <Shield className="h-16 w-16 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Protect Yourself from Phishing Attacks</h1>
          <p className="text-xl text-gray-600">
            Scan any suspicious URL to detect if it's a legitimate website or a potential phishing attempt.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-12">
          <form onSubmit={handleScan} className="mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="Enter URL to scan (e.g., https://example.com)"
                className="flex-grow px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors disabled:bg-blue-400"
              >
                {loading ? 'Scanning...' : 'Scan URL'}
              </button>
            </div>
            {error && <p className="mt-2 text-red-600">{error}</p>}
          </form>

          {result && (
            <div className={`p-4 rounded-lg ${result.result === 'phishing' ? 'bg-red-100' : 'bg-green-100'} transition-all duration-300 animate-fade-in`}>
              <div className="flex items-start">
                <div className={`p-2 rounded-full ${result.result === 'phishing' ? 'bg-red-200 text-red-600' : 'bg-green-200 text-green-600'} mr-4`}>
                  {result.result === 'phishing' ? <AlertTriangle className="h-6 w-6" /> : <CheckCircle className="h-6 w-6" />}
                </div>
                <div>
                  <h3 className={`text-lg font-semibold ${result.result === 'phishing' ? 'text-red-700' : 'text-green-700'}`}>
                    {result.result === 'phishing' ? 'Potential Phishing Website Detected!' : 'Legitimate Website'}
                  </h3>
                  <p className="text-gray-700">
                    {result.result === 'phishing'
                      ? 'This URL shows characteristics of a phishing attempt. Be careful!'
                      : 'This URL appears to be legitimate.'}
                  </p>
                  <p className="mt-2 text-sm text-gray-600">
                    Confidence: <span className="font-semibold">{(result.confidence * 100).toFixed(2)}%</span>
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="text-blue-600 mb-4">
              <Shield className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Advanced Detection</h3>
            <p className="text-gray-600">
              Our machine learning model analyzes multiple URL and content features to identify phishing attempts.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="text-blue-600 mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Real-time Protection</h3>
            <p className="text-gray-600">
              Get instant feedback on potentially dangerous websites before you share sensitive information.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="text-blue-600 mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Browser Extension</h3>
            <p className="text-gray-600">
              Install our Chrome extension for automatic scanning and alerts while browsing the web.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;