import React from 'react';
import { Shield, AlertCircle, Code, Users } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <Shield className="h-16 w-16 text-blue-600 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-gray-800 mb-4">About PhishGuard</h1>
          <p className="text-xl text-gray-600">
            Protecting you from phishing attacks with advanced machine learning.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 mb-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Mission</h2>
          <p className="text-gray-600 mb-6">
            PhishGuard was created with a simple but crucial mission: to protect internet users from the growing threat of phishing attacks. 
            We use advanced machine learning techniques to identify potential phishing websites, helping you browse the internet safely.
          </p>
          
          <h2 className="text-2xl font-bold text-gray-800 mb-4">How It Works</h2>
          <div className="space-y-6">
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="bg-blue-100 rounded-full p-2 text-blue-600">
                  <AlertCircle className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-1">URL Analysis</h3>
                <p className="text-gray-600">
                  Our system examines URLs for suspicious patterns, looking at length, special characters, 
                  and other features that might indicate a phishing attempt.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="bg-blue-100 rounded-full p-2 text-blue-600">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                  </svg>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-1">Domain Verification</h3>
                <p className="text-gray-600">
                  We check domain age, registration details, and SSL certificate status to determine 
                  if a website is newly created specifically for phishing purposes.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="bg-blue-100 rounded-full p-2 text-blue-600">
                  <Code className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-1">Content Inspection</h3>
                <p className="text-gray-600">
                  Our system analyzes HTML and JavaScript to identify suspicious forms, iframes, 
                  and other elements commonly used in phishing attempts.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="bg-blue-100 rounded-full p-2 text-blue-600">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-1">Machine Learning Decision</h3>
                <p className="text-gray-600">
                  Using XGBoost, our model combines all these features to make a final determination, 
                  providing a confidence score for its prediction.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full p-4 inline-block mb-4">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-1">Data Scientists</h3>
              <p className="text-gray-600">
                Experts in machine learning who developed and trained our phishing detection model.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-100 rounded-full p-4 inline-block mb-4">
                <Code className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-1">Software Engineers</h3>
              <p className="text-gray-600">
                Skilled developers who built our API and browser extension.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-100 rounded-full p-4 inline-block mb-4">
                <Shield className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-1">Security Experts</h3>
              <p className="text-gray-600">
                Professionals who keep our systems secure and up-to-date with the latest threats.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;