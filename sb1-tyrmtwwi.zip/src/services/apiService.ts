import axios from 'axios';
import { Scan, Stats } from '../types';

// In a real-world scenario, this would point to your deployed Flask API
const API_URL = 'http://localhost:5000';

export const scanUrl = async (url: string) => {
  try {
    const response = await axios.post(`${API_URL}/predict`, { url });
    return response.data;
  } catch (error) {
    console.error('Error scanning URL:', error);
    throw error;
  }
};

export const getStats = async (): Promise<Stats> => {
  try {
    const response = await axios.get(`${API_URL}/stats`);
    return response.data;
  } catch (error) {
    console.error('Error fetching stats:', error);
    throw error;
  }
};

export const getRecentScans = async (): Promise<Scan[]> => {
  try {
    const response = await axios.get(`${API_URL}/recent-scans`);
    return response.data;
  } catch (error) {
    console.error('Error fetching recent scans:', error);
    throw error;
  }
};